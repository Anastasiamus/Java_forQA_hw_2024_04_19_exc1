import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Author author1 = new Author(" Lev Tolstoy");
        Author author2 = new Author( " Anatoly Karpov");
        Author autor3 = new Author(" Sigmund Freud");

        List<Book> books = new ArrayList<>();

        books.add(new Book("War and Peace", author1, 1867, 960));
        books.add(new Book("Anna Karenina", author1, 1878, 864));
        books.add(new Book("Way of life", author1, 1910, 595));
        books.add(new Book("Childhood", author1, 1852, 187));

        books.add(new Book("Life and Chess", author2, 2022, 671));
        books.add(new Book("Learn to play chess", author2, 2004, 120));
        books.add(new Book("My best chess-games", author2, 2001, 400));

        books.add(new Book("The Interpretation of Dreams", autor3, 1900, 153));
        books.add(new Book("The Psychopathology of Everyday Life", autor3, 1901, 107));
        books.add(new Book("Totem and Taboo", autor3, 1913, 606));


        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number from 1 to 4");
        System.out.println("Enter number 1 to sort by Titel");
        System.out.println("Enter number 2 to sort by Author");
        System.out.println("Enter number 3 to sort by Year of publishing");
        System.out.println("Enter number 4 to sort by Count of pages");
        int choice = scanner.nextInt();

        Comparator<Book> comparator = null;
        switch (choice) {
            case 1:
                comparator = Comparator.comparing(Book::getTitel);
                break;
            case 2:
                comparator = Comparator.comparing(book -> book.getAuthor().getName());
                break;
            case 3:
                comparator = Comparator.comparing(Book::getYearOfPublishing);
                break;
            case 4:
                comparator = Comparator.comparing(Book::getCountOfPages);
                break;
            default:
                System.out.println("Error, enter a number from 1 to 4");
                return;
        }
        books.sort(comparator);

        for (Book book : books) {
            System.out.println(book);
        }
    }
}

   /*Есть класс книга. У книги есть название,автор, год издания,
        количество страниц. Автор является отдельным классом
        У нескольких книг может быть один и тот же автор
        Создать 10 книг и поместить их в список*/

    /*Создать несколько вариантов сортировки:
        1- По названию книги,
        2- По имени автора,
        3-По количеству страниц у книги
        4-По году издания*/

    /*С консоли запросить  ввод варианта сортировки в виде числа от 1 до 4
        В зависимости от того, какое число ввели отсортировать коллекцию
        нужным компаратором*/