public class Author {
    private String name;

    public Author(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Author{" +
                "name='" + name + '\'' +
                '}';
    }
}

/*Есть класс книга. У книги есть название,автор, год издания,
        количество страниц. Автор является отдельным классом
        У нескольких книг может быть один и тот же автор
        Создать 10 книг и поместить их в список*/
