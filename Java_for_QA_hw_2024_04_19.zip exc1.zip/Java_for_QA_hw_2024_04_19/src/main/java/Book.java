public class Book {
    private String titel;
    private Author author;
    private int yearOfPublishing;
    private int countOfPages;

    public Book(String titel, Author author, int yearOfPublishing, int countOfPages) {
        this.titel = titel;
        this.author = author;
        this.yearOfPublishing = yearOfPublishing;
        this.countOfPages = countOfPages;
    }
    public String getTitel() {
        return titel;
    }

    public Author getAuthor() {
        return author;
    }

    public int getYearOfPublishing() {
        return yearOfPublishing;
    }

    public int getCountOfPages() {
        return countOfPages;
    }

    @Override
    public String toString() {
        return "Book{" +
                "titel='" + titel + '\'' +
                ", author=" + author +
                ", yearOfPublishing=" + yearOfPublishing +
                ", countOfPages=" + countOfPages +
                '}';
    }
}

    /*Есть класс книга. У книги есть название,автор, год издания,
        количество страниц. Автор является отдельным классом
        У нескольких книг может быть один и тот же автор
        Создать 10 книг и поместить их в список*/

